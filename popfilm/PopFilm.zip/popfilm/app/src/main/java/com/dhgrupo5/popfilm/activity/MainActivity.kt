package com.dhgrupo5.popfilm.activity

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import com.dhgrupo5.popfilm.R

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}